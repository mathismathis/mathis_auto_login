HOW TO USE THIS PACKAGE


from example_package import mathis

mathis.youtube()
mathis.instagram()
mathis.facebook()
mathis.linkedin()


Source code

You can check the latest sources with the command:
https://github.com/mathismathis/mathis_auto_login


License
mathis is licensed under the MIT license. The full license text can be found here.


