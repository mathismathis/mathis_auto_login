import webbrowser


url='https://www.instagram.com/maestro_mathis/?hl=en'
url1='https://www.linkedin.com/in/mathis-t-794254222/'
url2='https://www.youtube.com/channel/UChAqVuW3nJCWdbbJOYEP00Q'
url3='https://www.youtube.com/channel/UChAqVuW3nJCWdbbJOYEP00Q'



def instagram():
    webbrowser.open(url)
def linkedin():
    webbrowser.open(url1)
def youtube():
    webbrowser.open(url2)
def facebook():
    webbrowser.open(url3)
