import webbrowser


url='https://www.youtube.com/watch?v=v4bkJef4W94'

webbrowser.open(url)